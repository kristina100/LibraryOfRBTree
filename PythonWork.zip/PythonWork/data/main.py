# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

import csv

import pandas as pd

data = pd.read_csv("book.csv")

new_data = data.replace('"', '')
new_datas = new_data.replace(',', ' ')

new_datas['score'].str.strip().replace(" ", ',')

# 将ISBN这一列提前
columns = list(new_datas)
columns.insert(0, columns.pop(columns.index('ISBN')))

# print(columns)

new_datas = new_datas.loc[:, columns]

# 将空格用逗号代替

print(type(new_datas['score']))

_list = []
for row in new_datas['score']:
    row = ' '.join(row.split())
    row = row.replace(' ', '=')
    _list.append(row)

# print(_list)
new_datas['score'] = _list
print(new_datas)

# 去除索引 写入文件
new_datas.to_csv('data_df.csv', index=False)
