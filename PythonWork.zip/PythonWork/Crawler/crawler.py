# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     crawler
   Description :
   Author :       HUAWEI
   date：          2021/5/14
-------------------------------------------------
   Change Activity:
                   2021/5/14:
-------------------------------------------------
"""
__author__ = 'HUAWEI'

# 从gevent库里导入monkey模块。
from bs4 import BeautifulSoup
from gevent import monkey
import lxml
monkey.patch_all()
import gevent, time, requests
from gevent.queue import Queue
from sql import user_sql
# 本地Chrome浏览器设置方法
# from selenium import webdriver  # 从options模块中调用Options类
# from selenium.webdriver.chrome.options import Options
# import request_ip
# # 实例化Option对象
# chrome_options = Options()
# # 把Chrome浏览器设置为静默模式
# chrome_options.add_argument('--headless')
# # 设置引擎为Chrome，在后台默默运行
#
# # 导入gevent、time、requests。
# import gevent, time, requests, bs4
# # 从gevent库里导入queue模块
import logging

LOG_FORMAT = "%(asctime)s - %(levelname)s - %(message)s"
logging.basicConfig(filename='my.log_crawler', level=logging.DEBUG, format=LOG_FORMAT)

# 查询IP 构建一个代理IP的格式
# url_0 = 'https://book.douban.com/tag/'
# headers = anti_spiders.fake_user_agent(url_0)
#
# proxy = [
#     {
#         'https': '113.128.34.14:47143',
#     },
#     {
#         'https': '113.128.24.241:36517',
#     },
#     """{
#         'http': '114.221.173.173:36726',
#         'https': '114.221.173.173:36726',
#     },
#
#     {
#         'https': '58.212.41.179:43315',
#         'http': '58.212.41.179:43315',
#     },
#     {
#         'http': '114.221.174.162:47597',
#         'https': '114.221.174.162:47597',
#     },
#     {
#         'http': '114.221.172.40:25665',
#         'https': '114.221.172.40:25665',
#     }"""
# ]
# proxies=random.choice(proxy), timeout=(3, 7)

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36'
}

# 创建队列对象，并赋值给work
work = Queue()

# def book_items():
# driver = webdriver.Chrome(r'C:\Program Files\Google\Chrome\Application\chromedriver.exe', options=chrome_options)
# driver.get('https://book.douban.com/tag/')
# time.sleep(2)
# 获取完整渲染的网页源代码
# pageSource = driver.page_source
# driver.close()

start = time.time()

url000 = 'https://book.douban.com/tag/'
res = requests.get(url000, headers=headers)
soup = BeautifulSoup(res.text, 'lxml')
# 得到了所有的类别
urls = soup.find_all('td')
# 分析单个类别
# index = 1
for url001 in urls:
    # 这里提取了文字
    url0 = url001.a.string
    url_list = []
    # 这里提取了单个类别的url01 例如小说 分析这个界面
    for j in range(25):
        m = 20 * j
        j += 1
        url01 = 'https://book.douban.com/tag/' + url0 + f"?start={m}&type=T"
        # 用put_nowait()函数可以把网址都放进队列里
        work.put_nowait(url01)


def crawler():
    # driver = webdriver.Chrome(r'C:\Program Files\Google\Chrome\Application\chromedriver.exe', options=chrome_options)
    # 当队列不是空的时候，就执行下面的程序
    while not work.empty():
        # 用get_nowait()函数可以把队列里的网址都取出
        url = work.get_nowait()
        # 获取数据
        res = requests.get(url, headers=headers)
        soup = BeautifulSoup(res.text, 'lxml')
        books = soup.find_all('li', class_="subject-item")
        for book in books:
            books_ = []
            # 去掉字符串收尾空格符
            book_name = book.find('h2').find('a').text.strip().replace(" ", "").replace("\n", "")
            # 单本书的url
            book_url = book.find('h2').find('a')['href']
            res = requests.get(book_url, headers=headers)
            soup = BeautifulSoup(res.text, 'lxml')

            """ get  users  urls """

            users = soup.find_all('li', class_="comment-item")
            users_com = {}
            i = 0
            for user in users:
                try:
                    user_com = user.find('p', class_="comment-content").text.replace(" ", "").replace("\n", "")
                except AttributeError:
                    continue
                users_com[i] = user_com
                i += 1

            try:
                cover_url = soup.find('div', id="content").find('a')['href']
                # 下载图片到本地
                dir = 'G:/picture/book_cover' + '/' + str(book_name) + '.png'
                try:
                    pic = requests.get(cover_url, headers=headers)
                    time.sleep(2)
                except AttributeError:
                    continue
                fp = open(dir, 'wb')
                fp.write(pic.content)
                fp.close()
            except AttributeError and OSError:
                continue
            # 基本信息
            base_info_dict_0 = {}
            # 储存字典
            base_info = soup.find('div', id="info").text.strip().replace(" ", "")
            base_info_list = base_info.split('\n')

            while '' in base_info_list:
                base_info_list.remove('')
            base_info_dict_0[base_info_list[0]] = base_info_list[1]
            for i in base_info_list:
                try:
                    j, k = i.split(':')
                    base_info_dict_0[j] = k

                except ValueError:
                    continue
            # 基本信息  分割
            author = base_info_dict_0.get('作者:')
            press = base_info_dict_0.get('出版社')
            publishing_year = base_info_dict_0.get('出版年')
            page_num = base_info_dict_0.get('页数')
            price = base_info_dict_0.get('定价')
            ISBN = base_info_dict_0.get('ISBN')
            Binding = base_info_dict_0.get('装帧')
            Series = base_info_dict_0.get('丛书')
            # 以第一个为基准
            # 豆瓣评分
            score = soup.find('div', class_="rating_wrap clearbox").text.strip().replace(" ", "").replace("\n",
                                                                                                          " ")
            # all of them
            info_all = soup.find_all('div', class_="intro")
            # 截取tag集合里需要的片段

            try:
                # 简介
                content_introduction = info_all[0].text
                # 作者简介
                author_com = info_all[1].text
                # book_id only
                # book_id = str(index)
            except IndexError:
                continue

            book_set = (
                str(book_name), str(author), str(press), str(publishing_year), str(score),
                str(page_num), str(price), str(ISBN),
                str(cover_url), str(author_com), str(users_com))
            logging.info(book_set)
            # index += 1
            books_.append(book_set)
            # 再把book_set这一条插入数据库中
            # 数据
            user_sql.insert_book(books_)

    # # 关闭浏览器
    # driver.close()


tasks_list = []
# 创建20个爬虫
for x in range(20):
    # 用gevent.spawn()函数创建执行crawler()函数的任务
    task = gevent.spawn(crawler)
    # 往任务列表添加任务
    tasks_list.append(task)
# 用gevent.joinall方法，执行任务列表里的所有任务，就是让爬虫开始爬取网站
gevent.joinall(tasks_list)
end = time.time()
print(end - start)
